Author: Lai Man Tang, Yuting Tan
Date: 12/09/2017

This project is aimed to implement a concurrent reader writer lock.
We implemented 4 clases. They are: readerTree, RWnode, RWlock and RWQueue.

readerTree is a Tree Structure that stored the incoming reader threads. We used SNZI tree data structure to implement the tree, so it is a scalable tree. The tree can resize itself. Although we set the initial size and radix to static numbers, no matter how many readers come in, we can always resize the tree for them. 

RWnode defines both the readers, writers and reader trees instances. 

RWqueue is a queue. All readers and writers go into the queue. For a reader, if it sees the queue is empty or the last item in the queue is a writer, it consturcts a reader tree for the following readers to get into the tree. If the reader sees another reader being the last item in the queue, it joins the reader tree the previous reader constructed. It has a inner class called QueueNode. A QueueNode has a pointer pointing to the next QueueNode and a pointer pointing to the RWnode it stores.


RWlock is the lock calss. We can call read_lock(), write_lock(), read_unlock(), write_unlock() functions.

We used pthread in this file and run it on the department server with C++ 11 environment. We have 32 readers and 2 writers.

To run it, using this command:
$scl enable devtoolset-7 bash
$gcc reader-writer-locker.cpp -lpthread -lstdc++ -lm

We run it for several times, sometimes we can get the correct answers, sometimes we get segmentation faults.

